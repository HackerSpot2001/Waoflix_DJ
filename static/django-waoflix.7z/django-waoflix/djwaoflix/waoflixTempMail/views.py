from django.shortcuts import render
from Modules.utils import data

def temp_mail(req):
    data['title'] = "Temp Mail "
    return render(req,"temp_mail.html",context=data)