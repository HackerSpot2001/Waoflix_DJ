from django.urls import path
from . import views


# Waoflix URLConf
urlpatterns = [
    path('',view=views.temp_mail,name='Temp-Mail Home'),
]