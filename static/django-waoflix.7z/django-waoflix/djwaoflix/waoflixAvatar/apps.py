from django.apps import AppConfig


class WaoflixavatarConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'waoflixAvatar'
