from django.apps import AppConfig


class WaoflixusersConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'waoflixUsers'
