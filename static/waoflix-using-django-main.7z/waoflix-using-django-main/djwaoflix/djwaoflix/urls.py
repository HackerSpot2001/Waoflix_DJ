from django.urls import path,include
from . import views


urlpatterns = [
    path('',view=views.home,name='Home'),
    path('contact/',view=views.contact,name='Contact'),
    path('about/',view=views.about,name='About'),
    path('waoflix/',include('waoflixApp.urls')),
    path('users/',include('waoflixUsers.urls')),
    path('temp-mail/',include("waoflixTempMail.urls")),
    path('avatar/',include('waoflixAvatar.urls')),
]
