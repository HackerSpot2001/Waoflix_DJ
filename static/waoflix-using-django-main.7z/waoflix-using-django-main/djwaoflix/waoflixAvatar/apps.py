from django.apps import AppConfig


class WaoflixavatarConfig(AppConfig):
    name = 'waoflixAvatar'
