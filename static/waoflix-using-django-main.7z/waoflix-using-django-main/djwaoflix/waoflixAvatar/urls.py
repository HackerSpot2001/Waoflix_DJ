from django.urls import path
from . import views


# Waoflix URLConf
urlpatterns = [
    path('',view=views.avatar,name='Avatar Home'),
    # path('login/',view=views.login,name='Waoflix Login'),
    # path('watch/<slug:slug>',view=views.watch_movie,name='Waoflix Watch Movie'),
]
