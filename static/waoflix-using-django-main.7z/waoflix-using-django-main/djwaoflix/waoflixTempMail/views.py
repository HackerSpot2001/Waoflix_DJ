from django.shortcuts import render

def temp_mail(req):
    return render(req,"temp_mail.html")
