from django.apps import AppConfig


class WaoflixtempmailConfig(AppConfig):
    name = 'waoflixTempMail'
