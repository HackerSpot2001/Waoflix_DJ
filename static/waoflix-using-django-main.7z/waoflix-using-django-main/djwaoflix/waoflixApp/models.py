from django.db import models as db
# Create your models here.


class waoflixContact(db.Model):
    sno = db.AutoField(primary_key=True)
    fname = db.CharField(max_length=25,null=False)
    lname = db.CharField(max_length=25,null=False)
    conMail = db.CharField(max_length=50,null=False)
    phoneNumber = db.CharField(max_length=13,null=False)
    conReason = db.CharField(max_length=200,null=False)
    date_created = db.DateTimeField(auto_now=True)
    
    def __repr__(self):
        return f"{self.fname} {self.lname} - {self.conMail}"

class WaoFlixComments(db.Model):
    sno = db.AutoField(primary_key=True)
    fname = db.CharField(max_length=25,null=False)
    comMail = db.CharField(max_length= 100,null=False)
    comReason = db.CharField(max_length=500,null=False)
    date_created = db.DateTimeField(auto_created=True)
    
    def __repr__(self):
        return f"{self.fname} - {self.comMail}"

class waoflixLogin(db.Model):
    sno = db.AutoField(primary_key=True)
    userName = db.CharField(max_length=25,null=False)
    sess_uuid = db.TextField(null=True)
    passWord = db.CharField(max_length=50,null=False)
    date_created = db.DateTimeField(auto_now=True)
    
    def __repr__(self):
        return f"{self.sno}"

class waoflixUsers(db.Model):
    sno = db.AutoField(primary_key=True)
    user_uuid_md5 =db.TextField(null=True)
    userName = db.CharField(max_length=25,null=False)
    passWord = db.CharField(max_length=50,null=False)
    userEmail = db.CharField(max_length=75,null=False)
    date_created = db.DateTimeField(auto_now=True)
    
    def __repr__(self):
        return f"{self.sno}"

class waoflixMovies(db.Model):
    sno = db.AutoField(primary_key=True)
    slug = db.CharField(max_length=150,null=False)
    poster_url = db.CharField(max_length=300,null=False)
    movie_title = db.CharField(max_length=300,null=False)
    movieRating = db.CharField(max_length=5,null=False)
    movieQuality = db.CharField(max_length=10,null=False)
    movieFileSize = db.CharField(max_length=10,null=False)
    movieLanguage = db.CharField(max_length=10,null=False)
    movieReleaseDate = db.CharField(max_length=20,null=False)
    movieStory = db.CharField(max_length=400,null=False)
    movieDownloadURL = db.CharField(max_length=1000,null=False)
    date_created = db.DateTimeField(auto_now=True)

    def __repr__(self):
        return f"{self.sno} - {self.slug}"



