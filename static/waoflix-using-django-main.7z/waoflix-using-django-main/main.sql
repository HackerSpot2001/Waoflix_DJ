begin;
-- drop table if EXISTS auth_user;
-- drop table if EXISTS auth_group;
-- drop table if EXISTS auth_group_permissions;
-- drop table if EXISTS auth_permission;
-- drop table if EXISTS auth_user_groups;
-- drop table if EXISTS auth_user_user_permissions;
-- drop table if EXISTS django_admin_log;
-- drop table if EXISTS django_content_type;
-- drop table if EXISTS django_migrations;
-- drop table if EXISTS django_session;

-- create table waoflixApp_waoflixlogin like waoflixapp_waoflixlogin;
-- create table waoflixApp_waoflixlogin like waoflixapp_waoflixlogin;
-- drop table if EXISTS waoflixApp_waoflixlogin;
drop table if EXISTS waoflixApp_waoflixlogin;
drop table if EXISTS waoflixApp_waoflixcontect;
drop table if EXISTS waoflixApp_waoflixcontact;
drop table if EXISTS waoflixApp_waoflixcomments;
drop table if EXISTS waoflixApp_waoflixmovies;
DROP TABLE IF EXISTS waoflixApp_waoflixusers;
CREATE TABLE waoflixApp_waoflixcontact AS SELECT * FROM waoflixapp_waoflixcontect;
CREATE TABLE waoflixApp_waoflixlogin AS SELECT * FROM waoflixapp_waoflixlogin;
CREATE TABLE waoflixApp_waoflixcomments AS SELECT * FROM waoflixapp_waoflixcomments;
CREATE TABLE waoflixApp_waoflixmovies AS SELECT * FROM waoflixapp_waoflixmovies;
CREATE TABLE waoflixApp_waoflixusers (
  sno int NOT NULL AUTO_INCREMENT,
  userName varchar(25) NOT NULL,
  userEmail varchar(25) NOT NULL,
  user_uuid_md5 longtext NOT NULL,
  passWord varchar(50) NOT NULL,
  date_created datetime DEFAULT NULL,
  PRIMARY KEY (`sno`)
);

commit;